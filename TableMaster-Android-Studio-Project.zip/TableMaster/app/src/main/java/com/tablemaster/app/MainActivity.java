package com.tablemaster.app;

import android.app.Activity;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.*;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Random;

public class MainActivity extends Activity {
    private final int BG = 0xFF101114, SURFACE = 0xFF1B1D23, ALT = 0xFF252832;
    private final int WHITE = 0xFFF4F5F7, MUTED = 0xFFA7ABB5, ACCENT = 0xFF8B7CFF;
    private final int GREEN = 0xFF35C98A, RED = 0xFFFF6B78;

    private LinearLayout root, content;
    private EditText tablesInput, countInput, answerInput;
    private TextView questionText, progressText, scoreText, feedbackText;
    private Button submitButton, nextButton;
    private int[] tables;
    private int totalQuestions, currentQuestion, score, first, second;
    private boolean answered, finished;
    private final Random random = new Random();
    private final List<String> mistakes = new ArrayList<>();
    private SharedPreferences prefs;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("table_master", MODE_PRIVATE);
        showSetup();
    }

    private void showSetup() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(18), dp(22), dp(24));
        root.setBackgroundColor(BG);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, -1));

        addText(content, "TABLE MASTER", 13, ACCENT, true, 0, 0, 0, 10);
        addText(content, "Make multiplication\nfeel effortless.", 29, WHITE, true, 0, 0, 0, 8);
        addText(content, "A quick daily workout for your mind. Practice offline, at your own pace.", 14, MUTED, false, 0, 0, 0, 26);

        addText(content, "TABLES TO PRACTISE", 12, MUTED, true, 0, 0, 0, 8);
        tablesInput = makeInput("Example: 2, 3, 4, 5", "2, 3, 4");
        content.addView(tablesInput, matchWrap(54));
        addText(content, "Enter numbers separated by commas (1–100).", 12, MUTED, false, 0, 5, 0, 20);

        addText(content, "NUMBER OF QUESTIONS", 12, MUTED, true, 0, 0, 0, 8);
        countInput = makeInput("Example: 20", "20");
        countInput.setInputType(InputType.TYPE_CLASS_NUMBER);
        content.addView(countInput, matchWrap(54));
        addText(content, "Choose between 1 and 500 questions.", 12, MUTED, false, 0, 5, 0, 24);

        Button start = makeButton("Start practice  →", ACCENT, WHITE);
        content.addView(start, matchWrap(56));
        start.setOnClickListener(v -> beginQuiz());

        LinearLayout best = panel();
        addText(best, "PERSONAL BEST", 11, MUTED, true, 0, 0, 0, 7);
        addText(best, prefs.getInt("best_score", 0) + " correct answers", 20, WHITE, true, 0, 0, 0, 2);
        addText(best, "Your highest correct-answer count in one session", 12, MUTED, false, 0, 0, 0, 0);
        addPanelToContent(best, 24);
        setContentView(root);
    }

    private void beginQuiz() {
        String raw = tablesInput.getText().toString().trim();
        String[] parts = raw.split(",");
        List<Integer> parsed = new ArrayList<>();
        try {
            for (String part : parts) {
                int value = Integer.parseInt(part.trim());
                if (value < 1 || value > 100) throw new NumberFormatException();
                parsed.add(value);
            }
            if (parsed.isEmpty()) throw new NumberFormatException();
            totalQuestions = Integer.parseInt(countInput.getText().toString().trim());
            if (totalQuestions < 1 || totalQuestions > 500) throw new NumberFormatException();
        } catch (Exception e) {
            toast("Enter valid tables (1–100) and a question count (1–500).");
            return;
        }
        tables = new int[parsed.size()];
        for (int i = 0; i < parsed.size(); i++) tables[i] = parsed.get(i);
        currentQuestion = 1;
        score = 0;
        mistakes.clear();
        finished = false;
        nextQuestion();
        showQuestion();
    }

    private void nextQuestion() {
        first = tables[random.nextInt(tables.length)];
        second = random.nextInt(10) + 1;
        answered = false;
    }

    private void showQuestion() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(18), dp(22), dp(24));
        root.setBackgroundColor(BG);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView brand = makeText("TABLE MASTER", 13, ACCENT, true);
        top.addView(brand, new LinearLayout.LayoutParams(0, -2, 1));
        top.addView(makeText("PRACTICE", 11, MUTED, true));
        root.addView(top);

        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setGravity(Gravity.CENTER_HORIZONTAL);
        body.setPadding(0, dp(34), 0, 0);
        root.addView(body, new LinearLayout.LayoutParams(-1, 0, 1));

        progressText = makeText("QUESTION " + currentQuestion + " OF " + totalQuestions, 12, MUTED, true);
        body.addView(progressText);
        scoreText = makeText("Score: " + score, 14, GREEN, true);
        LinearLayout.LayoutParams scoreParams = new LinearLayout.LayoutParams(-2, -2);
        scoreParams.topMargin = dp(10);
        body.addView(scoreText, scoreParams);

        LinearLayout card = panel();
        card.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(-1, dp(260));
        cardParams.topMargin = dp(35);
        body.addView(card, cardParams);

        addText(card, "SOLVE THIS", 12, MUTED, true, 0, 0, 0, 22);
        questionText = makeText(first + " × " + second, 42, WHITE, true);
        card.addView(questionText);
        answerInput = makeInput("Your answer", "");
        answerInput.setGravity(Gravity.CENTER);
        answerInput.setTextSize(22);
        answerInput.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_SIGNED);
        answerInput.setImeOptions(EditorInfo.IME_ACTION_DONE);
        LinearLayout.LayoutParams answerParams = matchWrap(58);
        answerParams.setMargins(dp(8), dp(24), dp(8), 0);
        card.addView(answerInput, answerParams);
        answerInput.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE) { checkAnswer(); return true; }
            return false;
        });

        feedbackText = makeText("", 14, WHITE, true);
        LinearLayout.LayoutParams feedbackParams = new LinearLayout.LayoutParams(-1, -2);
        feedbackParams.topMargin = dp(18);
        feedbackText.setGravity(Gravity.CENTER);
        body.addView(feedbackText, feedbackParams);

        submitButton = makeButton("Check answer", ACCENT, WHITE);
        LinearLayout.LayoutParams submitParams = matchWrap(56);
        submitParams.topMargin = dp(22);
        body.addView(submitButton, submitParams);
        submitButton.setOnClickListener(v -> checkAnswer());

        nextButton = makeButton(currentQuestion == totalQuestions ? "View results  →" : "Next question  →", GREEN, BG);
        LinearLayout.LayoutParams nextParams = matchWrap(56);
        nextParams.topMargin = dp(10);
        body.addView(nextButton, nextParams);
        nextButton.setVisibility(View.GONE);
        nextButton.setOnClickListener(v -> advance());

        Button end = makeButton("End practice", ALT, MUTED);
        LinearLayout.LayoutParams endParams = matchWrap(48);
        endParams.topMargin = dp(12);
        root.addView(end, endParams);
        end.setOnClickListener(v -> showSetup());

        setContentView(root);
        answerInput.requestFocus();
    }

    private void checkAnswer() {
        if (answered) return;
        String value = answerInput.getText().toString().trim();
        if (value.isEmpty()) { toast("Type your answer first."); return; }
        int expected = first * second;
        int entered;
        try { entered = Integer.parseInt(value); }
        catch (Exception e) { toast("Enter a valid whole number."); return; }

        answered = true;
        hideKeyboard();
        answerInput.setEnabled(false);
        submitButton.setVisibility(View.GONE);
        nextButton.setVisibility(View.VISIBLE);
        if (entered == expected) {
            score++;
            feedbackText.setText("✓  Correct! Great work.");
            feedbackText.setTextColor(GREEN);
        } else {
            feedbackText.setText("✕  Not quite. The answer is " + expected + ".");
            feedbackText.setTextColor(RED);
            mistakes.add(first + " × " + second + " = " + entered + "  |  Correct: " + expected);
        }
        scoreText.setText("Score: " + score);
        nextButton.setText(currentQuestion == totalQuestions ? "View results  →" : "Next question  →");
    }

    private void advance() {
        if (currentQuestion >= totalQuestions) {
            showResults();
        } else {
            currentQuestion++;
            nextQuestion();
            showQuestion();
        }
    }

    private void showResults() {
        int best = Math.max(score, prefs.getInt("best_score", 0));
        prefs.edit().putInt("best_score", best).apply();

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(24), dp(22), dp(24));
        root.setBackgroundColor(BG);
        ScrollView scroll = new ScrollView(this);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        content = body;
        scroll.addView(body);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, -1));

        addText(body, "TABLE MASTER", 13, ACCENT, true, 0, 0, 0, 24);
        addText(body, "Session complete.", 29, WHITE, true, 0, 0, 0, 8);
        addText(body, "Here is how you did. Keep practising to improve your personal best.", 14, MUTED, false, 0, 0, 0, 24);

        LinearLayout scoreCard = panel();
        scoreCard.setGravity(Gravity.CENTER);
        addText(scoreCard, "YOUR SCORE", 12, MUTED, true, 0, 0, 0, 10);
        addText(scoreCard, score + " / " + totalQuestions, 42, WHITE, true, 0, 0, 0, 8);
        int accuracy = Math.round(score * 100f / totalQuestions);
        addText(scoreCard, accuracy + "% accuracy", 16, GREEN, true, 0, 0, 0, 0);
        addPanelToContent(scoreCard, 20);

        LinearLayout stats = panel();
        addStat(stats, "Correct answers", String.valueOf(score), GREEN);
        addStat(stats, "Wrong answers", String.valueOf(totalQuestions - score), RED);
        addStat(stats, "Personal best", String.valueOf(best), WHITE);
        addPanelToContent(stats, 16);

        if (!mistakes.isEmpty()) {
            addText(body, "LET'S REVIEW", 12, MUTED, true, 0, 0, 0, 10);
            LinearLayout review = panel();
            for (String mistake : mistakes) {
                addText(review, mistake, 14, WHITE, false, 0, 8, 0, 8);
                View divider = new View(this);
                divider.setBackgroundColor(0xFF343741);
                review.addView(divider, new LinearLayout.LayoutParams(-1, dp(1)));
            }
            addPanelToContent(review, 20);
        }

        Button retry = makeButton("Practise again  →", ACCENT, WHITE);
        body.addView(retry, matchWrap(56));
        retry.setOnClickListener(v -> showSetup());
        Button same = makeButton("Repeat these tables", ALT, WHITE);
        LinearLayout.LayoutParams sameParams = matchWrap(52);
        sameParams.topMargin = dp(10);
        body.addView(same, sameParams);
        same.setOnClickListener(v -> {
            tablesInput = makeInput("", joinTables());
            countInput = makeInput("", String.valueOf(totalQuestions));
            beginQuizFromLast();
        });
        setContentView(root);
    }

    private void beginQuizFromLast() {
        currentQuestion = 1;
        score = 0;
        mistakes.clear();
        nextQuestion();
        showQuestion();
    }

    private String joinTables() {
        StringBuilder s = new StringBuilder();
        for (int i = 0; i < tables.length; i++) {
            if (i > 0) s.append(", ");
            s.append(tables[i]);
        }
        return s.toString();
    }

    private void addStat(LinearLayout box, String label, String value, int color) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView left = makeText(label, 14, MUTED, false);
        row.addView(left, new LinearLayout.LayoutParams(0, dp(38), 1));
        row.addView(makeText(value, 16, color, true));
        box.addView(row);
    }

    private LinearLayout panel() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18), dp(18), dp(18), dp(18));
        box.setBackground(round(SURFACE, 18));
        return box;
    }

    private void addPanelToContent(LinearLayout box, int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.bottomMargin = dp(bottom);
        content.addView(box, p);
    }

    private EditText makeInput(String hint, String value) {
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setText(value);
        input.setHint(hint);
        input.setHintTextColor(MUTED);
        input.setTextColor(WHITE);
        input.setTextSize(16);
        input.setPadding(dp(15), 0, dp(15), 0);
        input.setBackground(round(ALT, 12));
        return input;
    }

    private Button makeButton(String label, int color, int textColor) {
        Button button = new Button(this);
        button.setText(label);
        button.setAllCaps(false);
        button.setTextSize(15);
        button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        button.setTextColor(textColor);
        button.setBackground(round(color, 14));
        return button;
    }

    private TextView makeText(String value, int size, int color, boolean bold) {
        TextView text = new TextView(this);
        text.setText(value);
        text.setTextSize(size);
        text.setTextColor(color);
        if (bold) text.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return text;
    }

    private void addText(LinearLayout parent, String value, int size, int color, boolean bold,
                         int left, int top, int right, int bottom) {
        TextView text = makeText(value, size, color, bold);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(dp(left), dp(top), dp(right), dp(bottom));
        parent.addView(text, p);
    }

    private LinearLayout.LayoutParams matchWrap(int height) {
        return new LinearLayout.LayoutParams(-1, dp(height));
    }

    private GradientDrawable round(int color, int radius) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radius));
        return drawable;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void hideKeyboard() {
        try {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(answerInput.getWindowToken(), 0);
        } catch (Exception ignored) {}
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
