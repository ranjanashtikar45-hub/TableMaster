# Table Master — Android Studio project

A lightweight, offline Android multiplication-table practice app.

## Features
- Choose one or more multiplication tables (comma-separated, 1–100).
- Choose 1–500 random questions per session.
- Immediate answer feedback.
- Session score, accuracy, and wrong-answer review.
- Saves the personal-best correct-answer count locally on the device.
- No internet permission or account required.

## Build an APK on Windows
1. Install Android Studio (and its recommended Android SDK components).
2. Extract this ZIP file.
3. In Android Studio, choose **Open** and select the extracted `TableMaster` folder (the folder containing `settings.gradle`).
4. Allow Gradle sync to finish.
5. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. When the build completes, click **locate** in the notification. The debug APK is at `app/build/outputs/apk/debug/app-debug.apk`.
7. Copy `app-debug.apk` to your Android phone and install it. If prompted, allow installation from that file manager.

## Project details
- Native Android app written in Java.
- Minimum Android version: Android 6.0 (API 23).
- Compile/target SDK: 35.
- Android Gradle Plugin: 8.7.3.

The project source is provided; an APK has not been compiled or device-tested in this environment.
